﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour {
	
	GameObject anim;   //this is the explosion effect
	public int life;
	public float speed;
	public float x1;
	public float x2;
	private bool direction = false;
	private Transform playerGraphics;
	void Start() 
	{
		GameManager.GameStart += GameStart;
		GameManager.GameOver  += GameOver;
		anim = this.transform.FindChild ("Explosion").gameObject;
		anim.gameObject.SetActive (false);
		playerGraphics = transform.FindChild ("Graphics");
	}

	void OnCollisionEnter2D(Collision2D other)
	{
		if(gameObject!=null&&other!=null){
			if (other.gameObject.tag == "Player") {
				float SpongeY =other.transform.localPosition.y; 
				float enemeyY =this.transform.localPosition.y;
				if(enemeyY-SpongeY<0.8f){
					Destroy(gameObject);
				}
			} else  if(other.gameObject.name.IndexOf("BulletTrail")>=0){
				this.life-=1;
				anim.gameObject.SetActive (true);
				if(this.life==0)
					gameObject.SetActive(false);
			}else if(gameObject.gameObject.tag.IndexOf("enemy")>=0){

			}
		}
		direction = !direction;
	}
	void OnCollisionExit2D(Collision2D other) {
		if (other.gameObject.name.IndexOf ("BulletTrail") >= 0) {
			anim.gameObject.SetActive(false);
			other.gameObject.SetActive(false);
		}
	}
	void FixedUpdate (){
		if (!direction) {
			this.transform.Translate (new Vector2 (Time.deltaTime, 0f));
			if(this.transform.localPosition.x>=x2){
				direction = true;
				flip();
			}
		}else{
			this.transform.Translate(new Vector2(0-Time.deltaTime,0f));
			if(this.transform.localPosition.x<=x1){
				direction = false;
				flip();
			}
		}
	}
	
	void Patrolling (){

	}
	private void GameStart(){

	}
	private void GameOver(){

	}
	private void flip(){
		Debug.Log (playerGraphics.localScale.x);
		Vector3 theScale = playerGraphics.localScale;
		theScale.x *= -1;
		playerGraphics.localScale = theScale;
		Debug.Log (playerGraphics.localScale.x);
	}
}
