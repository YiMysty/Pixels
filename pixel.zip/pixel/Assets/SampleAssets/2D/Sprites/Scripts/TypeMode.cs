﻿using UnityEngine;
using System.Collections;

public class TypeMode
{
	public static int NORMALSPONGE = 0;
	public static int MUSCLESPONGE = 1;
	public static int GUNSPONGE    = 2;
	public static int OCTOPUS      =20;  //The enemy cost the blood change
}
